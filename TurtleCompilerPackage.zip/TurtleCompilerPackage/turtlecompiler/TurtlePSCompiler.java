package turtlecompiler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;

import turtlecompiler.grammar.*;
import turtlecompiler.lexer.*;
import turtlecompiler.parser.*;

public class TurtlePSCompiler {
    public static void main(String[] args) {
        //make sure sufficient arguments are provided
        if (args.length < 2) {
            System.out.println("Usage: java turtlecompiler.TurtlePSCompiler <inputfile> <outputfile>");
            return; //returns from the main method, thus ends the program
        }
        //default to PostScript output
        String output = "postscript";
        if (args.length == 3) {
            output = args[2].toLowerCase();
        }

        //make sure we can access the input/output files
        InputStream input = null;
        PrintWriter printWriter = null;
        try {
            input = new FileInputStream(new File(args[0]));
            printWriter = new PrintWriter(new PrintStream(args[1]));
        }
        catch (IOException e) {
            System.out.println("Could not open input/output file: " + e.getMessage());
            return; //returns from the main method, thus ends the program
        }

        // initialise a lexer for the source file
        Lexer lexer = new Lexer(input);

        // initialise the parser and parse the source
        Parser parser = new Parser(lexer);
        Prog prog = parser.parse();

        // Check for syntax errors
        if (parser.hasError() || prog == null) {
            System.err.println("Syntax errors detected. No output generated.");
            printWriter.close();
            return; // Exit program
        }

        //generate the postscript (or turtlescript) code
        if (output.equals("postscript")) {
            printWriter.write(prog.toPostScript());
        } else if (output.equals("turtlescript")) {
            printWriter.write(prog.toTurtleScript());
        } else {
            System.err.println("Error: Invalid output format. Use 'postscript' or 'turtlescript'.");
            printWriter.close();
            return; // Exit program
        }

        //close the print writer for the output file
        printWriter.close();
        System.out.println("Compilation successful. Output written to " + args[1]);
    }
}
