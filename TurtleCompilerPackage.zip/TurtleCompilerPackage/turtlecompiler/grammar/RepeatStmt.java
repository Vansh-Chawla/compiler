package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;
import java.util.*;

/*
 * "repeat" num '{' { stmt } '}'
 */
public class RepeatStmt extends Stmt {

    private Token name;
    private Token num;
    private Token LBrace;
    private List<Stmt> stmts = new ArrayList<>();
    private Token RBrace;

    public RepeatStmt (Token name, Token num, Token LBrace, List<Stmt> stmts, Token RBrace) {
        this.name = name;
        this.num = num;
        this.LBrace = LBrace;
        this.stmts = stmts;
        this.RBrace = RBrace;
    }

    public String toTurtleScript() {

        StringBuilder builder = new StringBuilder();
        for (Stmt stmt : stmts) {
            builder.append(stmt.toTurtleScript());
        }

        return name.getTurtleValue() + " " + num.getTurtleValue() + " " + LBrace.getTurtleValue() + " " + builder.toString() + RBrace.getTurtleValue() + "\n";
    }

    public String toPostScript() {

        StringBuilder builder = new StringBuilder();
        for (Stmt stmt : stmts) {
            builder.append(stmt.toPostScript());
        }

        return num.getPSValue() + " " + LBrace.getPSValue() + "\n" + builder.toString() + RBrace.getPSValue() + " " + name.getPSValue() + "\n\n";
    }
}