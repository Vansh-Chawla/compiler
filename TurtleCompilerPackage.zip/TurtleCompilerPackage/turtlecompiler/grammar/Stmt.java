package turtlecompiler.grammar;

/* 
 * Acts solely as a super class for the actual statements 
 * (left, right, forward, if, repeat, ...)
 */
public abstract class Stmt {
    public abstract String toPostScript();
    public abstract String toTurtleScript();
}
