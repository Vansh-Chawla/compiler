package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;
import java.util.*;

/*
 *   statement::= ident expr
 */
public class CallStmt extends Stmt {
    private Token name;
    private List<Expr> args;

    public CallStmt(Token name, List<Expr> args) {
        this.name = name;
        this.args = args;
    }

    public String toPostScript() {
        // postfix notation -> arg name 
        StringBuilder builder = new StringBuilder();
        // push the argument so the procedure can access it
        for (Expr arg : args) {
            builder.append(arg.toPostScript()).append(" ");
        }
        // push Heading so procedure can access it
        builder.append(" Heading ");
        // call the procedure
        builder.append(name.getPSValue());
        builder.append("\n");
        // pop and update the Heading to access and chnages to turtle direction
        builder.append("/Heading exch def\n");
        return builder.toString();
    }

    public String toTurtleScript() {
        // prefix notation -> name arg
        StringBuilder builder = new StringBuilder();
        // call the procedure
        builder.append(name.getTurtleValue());
        builder.append(" ");
        // evaluate the procedure argument
        for (Expr arg : args) {
            builder.append(arg.toTurtleScript());
        }
        builder.append("\n");
        return builder.toString();
    }
}
