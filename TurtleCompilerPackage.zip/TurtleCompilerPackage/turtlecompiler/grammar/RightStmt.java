package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;

/*
 * "turnright" expr
 */
public class RightStmt extends Stmt {
    private Token name;
    private Expr distance;

    public RightStmt (Token name, Expr distance) {
        this.name = name;
        this.distance = distance;
    }

    public String toTurtleScript() {
        return name.getTurtleValue() + " " + distance.toTurtleScript() + "\n";
    }

    public String toPostScript() {
        // reverse order for PostScript
        return distance.toPostScript() + " " + name.getPSValue() + "\n";
    }
}