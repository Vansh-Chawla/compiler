package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;

/*
 * num::= { digit }
 */
public final class NumExpr extends Expr {
    private final Token numToken;

    public NumExpr(Token numToken) {
        this.numToken = numToken;
    }

    public String toPostScript() {
        return numToken.getPSValue();
    }

    public String toTurtleScript() {
        return numToken.getTurtleValue();
    }
}
