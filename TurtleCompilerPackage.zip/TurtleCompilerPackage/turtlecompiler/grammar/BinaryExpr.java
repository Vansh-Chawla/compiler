package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;

/*
 * binary-expr::= expr op expr
 *
 * where op is one of '+',  '-',  '*', '/',
 *                      '==', '!=', '>', '<', '<=', '>='
 */
public final class BinaryExpr extends Expr {
    private Expr left;
    private Token oper;
    private Expr right;

    public BinaryExpr(Expr left, Token oper, Expr right) {
        this.left = left;
        this.oper = oper;
        this.right = right;
    }

    public String toPostScript() {
        StringBuilder builder = new StringBuilder();
        // postfix notation -> left right operator
        builder.append(left.toPostScript());
        builder.append(" ");
        builder.append(right.toPostScript());
        builder.append(" ");
        builder.append(oper.getPSValue());
        return builder.toString();
    }

    public String toTurtleScript() {
        StringBuilder builder = new StringBuilder();
        // infix notation -> left operator right
        builder.append(left.toTurtleScript());
        builder.append(" ");
        builder.append(oper.getTurtleValue());
        builder.append(" ");
        builder.append(right.toTurtleScript());
        return builder.toString();
    }
}