package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;
import java.util.*;

/*
 * "if" expr '{' { stmt } '}' "else" '{' { stmt } '}'
 */
public class IfElseStmt extends Stmt {

    private Token ifName;
    private Expr expr;
    private Token ifLBrace;
    private List<Stmt> ifStmts = new ArrayList<>();
    private Token ifRBrace;
    private Token elseName;
    private Token elseLBrace;
    private List<Stmt> elseStmts = new ArrayList<>();
    private Token elseRBrace;


    public IfElseStmt (Token ifName, Expr expr, Token ifLBrace, List<Stmt> ifStmts, Token ifRBrace, Token elseName, Token elseLBrace, List<Stmt> elseStmts, Token elseRBrace) {     
        this.ifName = ifName;
        this.expr = expr;
        this.ifLBrace = ifLBrace;
        this.ifStmts = ifStmts;
        this.ifRBrace = ifRBrace;
        this.elseName = elseName;
        this.elseLBrace = elseLBrace;
        this.elseStmts = elseStmts;
        this.elseRBrace = elseRBrace;

        // if there is no "else" statement, initialize the rest of the tokens and statements as null
        if (elseName == null) {
            this.elseName = null;
            this.elseLBrace = null;
            this.elseStmts = new ArrayList<>();
            this.elseRBrace = null;
        }
    }

    public String toTurtleScript() {
        StringBuilder result = new StringBuilder();
        result.append(ifName.getTurtleValue()).append(" ").append(expr.toTurtleScript()).append(" ").append(ifLBrace.getTurtleValue()).append("\n");
        for (Stmt stmt : ifStmts) {
            result.append(stmt.toTurtleScript());
        }
        result.append(ifRBrace.getTurtleValue()).append("\n");
        if (elseName != null) {  
            result.append(elseName.getTurtleValue()).append(" ").append(elseLBrace.getTurtleValue()).append("\n");
            for (Stmt stmt : elseStmts) {
                result.append(stmt.toTurtleScript());
            }
            result.append(elseRBrace.getTurtleValue()).append("\n");
        }
        return result.toString();
    }
    
    public String toPostScript() {
        StringBuilder result = new StringBuilder();
        result.append(expr.toPostScript()).append(" ").append(ifLBrace.getPSValue()).append("\n");
        for (Stmt stmt : ifStmts) {
            result.append(stmt.toPostScript());
        }
        result.append(ifRBrace.getPSValue()).append(" ");
        if (elseName != null) {
            result.append(elseLBrace.getPSValue()).append("\n");
            for (Stmt stmt : elseStmts) {
                result.append(stmt.toPostScript());
            }
            result.append(elseRBrace.getPSValue()).append(" ifelse").append("\n");
        } else {
            result.append("if\n");
        }
        return result.toString();
    }
      
}