package turtlecompiler.grammar;

import java.util.List;

import turtlecompiler.lexer.Token;

/*
 * proc::= "learn" ident param block 
 */
public final class Proc {
    private Token name;
    private List<Token> args;
    private List<Stmt> stmts;

    public Proc(Token name, List<Token> args, List<Stmt> stmts) {
        this.name = name;
        this.args = args;
        this.stmts = stmts;
    }

    public String toPostScript() {
        StringBuilder builder = new StringBuilder();
        //procedure name
        builder.append("\n/");
        builder.append(name.getPSValue());
        builder.append(" {\n");
        //procedure argument popped off stack and put in dictionary 
        //also pop Heading to ensure turtle will move in the right direction
        if (args.size() > 1) {
            builder.append("3 dict begin\n");  // for cases where there is more than one PARAM
        } else {
            builder.append("2 dict begin\n");
        }
        builder.append("/Heading exch def\n");
        for (int i = args.size() - 1; i >= 0; i--) {
            builder.append("/");
            builder.append((args.get(i)).getPSValue());
            builder.append(" exch def\n"); // append for each PARAM in reverse order
        }
        //procedure body
        for (Stmt stmt : stmts) {
            builder.append(stmt.toPostScript());
        }
        //procedure end
        //also push Heading so any changes made to turtle direction can be accessed
        builder.append("Heading end } def\n");
        return builder.toString();
    }

    public String toTurtleScript() {
        StringBuilder builder = new StringBuilder();
        builder.append("\nlearn ");
        builder.append(name.getTurtleValue());
        builder.append(" ");
        for (Token arg : args) {
            builder.append(arg.getTurtleValue());
        }
        builder.append(" {\n");
        for (Stmt stmt : stmts) {
            builder.append(stmt.toTurtleScript());
        }
        builder.append("}\n");
        return builder.toString();
    }
}
