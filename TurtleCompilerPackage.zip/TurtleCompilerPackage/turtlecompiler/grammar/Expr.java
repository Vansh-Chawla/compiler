package turtlecompiler.grammar;

/*
 * Acts solely as a super class for the actual expressions 
 * (primary or binary)
 */
public abstract class Expr {
    public abstract String toPostScript();
    public abstract String toTurtleScript();
}
