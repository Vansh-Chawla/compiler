package turtlecompiler.grammar;
import turtlecompiler.lexer.Token;

/*
 * param::= '$' { letter|digit }
 */
public final class ParamExpr extends Expr {
    private final Token paramToken;

    public ParamExpr(Token paramToken) {
        this.paramToken = paramToken;
    }

    public String toPostScript() {
        return paramToken.getPSValue();
    }

    public String toTurtleScript() {
        return paramToken.getTurtleValue();
    }
}
