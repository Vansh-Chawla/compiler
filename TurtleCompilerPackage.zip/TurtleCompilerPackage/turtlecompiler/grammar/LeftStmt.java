package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;

/*
 * "turnleft" expr
 */
public class LeftStmt extends Stmt {
    private Token name;
    private Expr distance;

    public LeftStmt (Token name, Expr distance) {
        this.name = name;
        this.distance = distance;
    }

    public String toTurtleScript() {
        return name.getTurtleValue() + " " + distance.toTurtleScript() + "\n";
    }

    public String toPostScript() {
        // reverse order for PostScript
        return distance.toPostScript() + " " + name.getPSValue() + "\n";
    }
}