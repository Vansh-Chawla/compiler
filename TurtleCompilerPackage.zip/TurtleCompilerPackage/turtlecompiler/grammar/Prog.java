package turtlecompiler.grammar;

import java.util.List;

/*
 * prog::= { proc } { stmt }
 */
public class Prog {
    private List<Proc> procs;
    private List<Stmt> stmts;

    public Prog(List<Proc> procs, List<Stmt> stmts) {
        this.procs = procs;
        this.stmts = stmts;
    }

    // gets the standard starter needed for our TurtleScript conversion to PostScipt to work
    private String psPrologue() {
        return """
        %!PS-Adobe-3.0
        /Xpos    { 300 } def
        /Ypos    { 500 } def
        /Heading { 0   } def
        /Right   {
        Heading exch add Trueheading
        /Heading exch def
        } def
        /Left {
        Heading exch sub Trueheading
        /Heading exch def
        } def
        /Trueheading {
        360 mod dup
        0 lt { 360 add } if
        } def
        /Forward {
        dup  Heading sin mul
        exch Heading cos mul
        2 copy Newposition
        rlineto
        } def
        /Newposition {
        Heading 180 gt Heading 360 lt
        and { neg } if exch
        Heading  90 gt Heading 270 lt
        and { neg } if exch
        Ypos add /Ypos exch def
        Xpos add /Xpos exch def
        } def
        """;
    }

    // gets the standard ending needed for our TurtleScript conversion to PostScipt to work
    public String psEpilogue() {
        return """
        stroke
        showpage
        """;
    }

    //returns the PostScript code for this program
    public String toPostScript() {
        StringBuilder builder = new StringBuilder();
        //add the starter
        builder.append(psPrologue());
        //add the code for all the procedures
        for (Proc proc : procs) {
            builder.append(proc.toPostScript());
        }
        //add code to move the start to a sensible spot
        builder.append("Xpos Ypos moveto\n");
        //add the code for all the statements 
        for (Stmt stmt : stmts) {
            builder.append(stmt.toPostScript());
        }
        builder.append(psEpilogue());
        return builder.toString();
    }

    //returns the TurtleScript for this program (generated from the AST)
    public String toTurtleScript() {
        StringBuilder builder = new StringBuilder();
        //add the code for all the procedures
        for (Proc proc : procs) {
            builder.append(proc.toTurtleScript());
        }
        //add the code for all the statements
        for (Stmt stmt : stmts) {
            builder.append(stmt.toTurtleScript());
        }
        return builder.toString();
    }
}
