package turtlecompiler.grammar;

import turtlecompiler.lexer.Token;

/*
 * "forward" expr
 */
public class ForwardStmt extends Stmt {
    private Token name;
    private Expr distance;

    public ForwardStmt (Token name, Expr distance) {
        this.name = name;
        this.distance = distance;
    }

    public String toTurtleScript() {
        return name.getTurtleValue() + " " + distance.toTurtleScript() + "\n";
    }

    public String toPostScript() {
        // reverse order for PostScript
        return distance.toPostScript() + " " + name.getPSValue() + "\n";
    }
}