package turtlecompiler.parser;

import turtlecompiler.grammar.*;
import turtlecompiler.lexer.*;

import java.util.ArrayList;
import java.util.List;


public final class Parser {
    private Token token;
    private boolean error;
    private Lexer lexer;

    public Parser(Lexer lexer) {
        this.error = false;
        this.lexer = lexer;
    }

    public Token token() {
        return token;
    }

    public Token next() {
        token = lexer.next();
        return token();
    }

    public boolean hasError() {
        return error;
    }

    public Prog parse() {
        this.next();
        return parseProg();
    }

    private Prog parseProg() {
        //parse procedure definitions
        List<Proc> procs = new ArrayList<>();
        while (this.token() == Token.PROC_TOKEN) {
            procs.add(parseProc());
        }

        //parse statements
        List<Stmt> stmts = new ArrayList<Stmt>();
        while (this.token() != Token.EOI_TOKEN) {
            Stmt stmt = parseStmt();
            if (stmt == null) {
                System.out.println("Syntax error- invalid statement on line " + lexer.getLineCounter()); // if stmt is null return error with line number
                error = true;
                break;
            }
            stmts.add(stmt); // add the letters or digits that follow to the string builder
        }

        return new Prog(procs, stmts);
    }

    private Proc parseProc() {
        Token name = null;
        List<Token> args = new ArrayList<>(); // use a list for the cases where there is more than one PARAM

        // ignore the 'learn' keyword
        if (this.token().getType() == Type.PROC) {
            this.next();
        }

        // get the procedure name
        if (this.token().getType() == Type.IDENT) {
            name = this.token();
            this.next();
        } else {
            System.out.println("Syntax error- expected procedure name on line " + lexer.getLineCounter()); // return an error and line number if the IDENT was not parsed
            error = true;
        }

        // get the procedure parameter
        while (this.token().getType() == Type.PARAM) { // create a loop to add the multiple PARAMS if there are more than one
            args.add(this.token());                      
            this.next();
            if (this.token().getType() == Type.COMMA) {
                this.next(); //Skips the comma
            } else {
                break;
            }
        }

        // ignore the lbrace to start procedure body
        if (this.token().getType() == Type.LBRACE) {
            this.next();
        }  else {
            System.out.println("Syntax error expected '{' on line " + lexer.getLineCounter() +  " to start."); // returns an error with the line number if L brace is missing
            error = true;
        }
        
        // get the procedure body
        List<Stmt> stmts = new ArrayList<>();
        while (this.token().getType() != Type.RBRACE) { // adds statements until an R brace is reached
            Stmt stmt = parseStmt();
            if (stmt == null) {
                System.out.println("Syntax error- invalid statement on line " + lexer.getLineCounter()); // returns an error with its line number if the stmt is null
                error = true;
                break;
            }
            stmts.add(stmt);
        }
        this.next(); // ignore the RBRACE ending the procedure

        return new Proc(name, args, stmts);
    }

    // identify statement and parse it correctly
    private Stmt parseStmt() {
        Stmt stmt = null;
        switch(this.token().getType()) {
            case Type.FORWARD:
                Token forwardToken = this.token();
                this.next();
                Expr FTexpr = parseExpr();
                stmt = new ForwardStmt(forwardToken, FTexpr); // return a ForwardStmt object
                break;
            case Type.LEFT:
                Token leftToken = this.token();
                this.next();
                Expr LTexpr = parseExpr();
                stmt = new LeftStmt(leftToken, LTexpr); // return a LeftStmt object
                break;
            case Type.RIGHT:
                Token rightToken = this.token();
                this.next();
                Expr RTexpr = parseExpr();
                stmt = new RightStmt(rightToken, RTexpr); // return a RightStmt object
                break;
            case Type.REPEAT:
                Token repeatToken = this.token();
                this.next();
                if (this.token().getType() == Type.NUM) { // check that the next token is a number
                    Token num = this.token();
                    this.next();
                    if (this.token().getType() == Type.LBRACE) { // check the number is followed by a L brace
                        Token LBraceToken = this.token();
                        this.next();
                        List<Stmt> stmts = new ArrayList<>();
                        while (this.token().getType() != Type.RBRACE && this.token().getType() != Type.EOI) {  // add parsed statements to list until you reach an R brace
                            stmts.add(parseStmt());
                        }
                        if (this.token().getType() == Type.RBRACE) {
                            Token RBraceToken = this.token();
                            this.next();
                            stmt = new RepeatStmt(repeatToken, num, LBraceToken, stmts, RBraceToken); // return RepeatStmt once you have reached an R brace
                        } else {
                            System.out.println("Syntax error- expected '}' on line " + lexer.getLineCounter()); // return error if no R brace was found after the statements
                            error = true;
                        }
                    } else {
                        System.out.println("Syntax error- expected '{' on line " + lexer.getLineCounter());  // return an error if no L brace was found after the number
                        error = true;
                    }
                } else {
                    System.out.println("Syntax error- expected number on line " + lexer.getLineCounter()); // return an error if the next token after "repeat" is not a number
                    error = true;
                }
                break;
            case Type.IF:
                Token ifName = this.token();
                this.next();
                Expr ifExpr = parseExpr();
                
                if (ifExpr == null) {  // Check if the expression is valid
                    System.out.println("Syntax error - expected valid expression for 'if' condition on line " + lexer.getLineCounter());
                    error = true;
                    return null;
                }
            
                // Expect '{' after if condition
                if (this.token().getType() != Type.LBRACE) {
                    System.out.println("Syntax error - expected '{' on line " + lexer.getLineCounter());
                    error = true;
                    return null;
                }
                Token ifLBrace = this.token();
                this.next();
            
                // Parse statements inside if-block
                List<Stmt> ifStmts = new ArrayList<>();
                while (this.token().getType() != Type.RBRACE && this.token().getType() != Type.EOI) {
                    ifStmts.add(parseStmt());
                }
            
                // Expect '}' to close the if-block
                if (this.token().getType() != Type.RBRACE) {
                    System.out.println("Syntax error - expected '}' on line " + lexer.getLineCounter());
                    error = true;
                    return null;
                }
                Token ifRBrace = this.token();
                this.next();
            
                // Check if 'else' exists (optional)
                if (this.token().getType() == Type.ELSE) {
                    Token elseToken = this.token();
                    this.next();
            
                    // Expect '{' after else
                    if (this.token().getType() != Type.LBRACE) {
                        System.out.println("Syntax error - expected '{' on line " + lexer.getLineCounter());
                        error = true;
                        return null;
                    }
                    Token elseLBrace = this.token();
                    this.next();
            
                    // Parse statements inside else-block
                    List<Stmt> elseStmts = new ArrayList<>();
                    try {
                        while (this.token().getType() != Type.RBRACE && this.token().getType() != Type.EOI) {
                            elseStmts.add(parseStmt());
                        }
                    } catch (OutOfMemoryError oome) {
                        System.out.println("");
                    }
            
                    // Expect '}' to close the else-block
                    if (this.token().getType() != Type.RBRACE) {
                        System.out.println("Syntax error - expected '}' on line " + lexer.getLineCounter());
                        error = true;
                        return null;
                    }
                    Token elseRBrace = this.token();
                    this.next();
            
                    // Create IfElseStmt
                    stmt = new IfElseStmt(ifName, ifExpr, ifLBrace, ifStmts, ifRBrace, elseToken, elseLBrace, elseStmts, elseRBrace);
                } else {
                    // No else block, create an IfElseStmt with empty else statements
                    stmt = new IfElseStmt(ifName, ifExpr, ifLBrace, ifStmts, ifRBrace, null, null, new ArrayList<>(), null);
                }
                break;            

            case Type.IDENT:
                Token identToken = this.token();
                this.next();
                List<Expr> exprs = new ArrayList<>();
                while (this.token().getType() == Type.PARAM || this.token().getType() == Type.NUM) { // add any PARAMs or NUMs that follow
                    exprs.add(parseExpr());
                    if (this.token().getType() == Type.COMMA) {
                        this.next();      //Skips the comma
                    } else {
                        break;
                    }
                }
                stmt = new CallStmt(identToken, exprs); // return  a CallStmt object
                break;
        }
        return stmt;
    }

    private Expr parseExpr() {
        return fraserHanson(1);
    }

    // Binary Expressions precedence handler from Fraser and Hanson C Compiler book.
    private Expr fraserHanson(int k) {
        int i;
        Expr left;
        Token oper;
        Expr right;
        left = parsePrimaryExpr();

        for (i = this.token().getPrecedence(); i >= k; i--) {
            while (this.token().getPrecedence() == i) {
                oper = this.token();
                this.next();
                right = fraserHanson(i + 1);
                left = new BinaryExpr(left, oper, right);
            }
        }
        return left;
    }

    private Expr parsePrimaryExpr() {
        Token currentToken = this.token();

        if (currentToken.getType() == Type.NUM) {
            Expr expr = new NumExpr(currentToken); // create a NumExpr object
            this.next();
            return expr;
        } else if (currentToken.getType() == Type.PARAM) {
            Expr expr = new ParamExpr(currentToken); // create a ParamExpr object
            this.next();
            return expr;
        } else {
            System.err.println("Syntax Error: Expected a number or parameter, but found " + currentToken.getType() + " on line " + lexer.getLineCounter()); // return an error if there are no PARAMs or NUMs
            error = true;
            return null;
        }
    }

}
