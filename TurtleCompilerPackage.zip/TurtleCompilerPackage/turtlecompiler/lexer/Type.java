package turtlecompiler.lexer;

public enum Type {
    // Arithmetic Operators (TurtleScript , PostScript, Precedence)
    DIVIDE, // "/" , "div", 4
    TIMES,  // "*" , "mul", 4
    MINUS,  // "-" , "sub", 3
    PLUS,   // "+" , "add", 3

    // Comparison Operators (TurtleScript , PostScript, Precedence)
    GE, // ">=" , "ge", 2
    GT, // ">" , "gt", 2
    LE, // "<=" , "le", 2
    LT, // "<" , "lt", 2
    EQ, // "==" , "eq", 1
    NE, // "!=" , "ne", 1

    // Identifiers, Numbers, and Parameters
    IDENT,  // Variable names and procedure names
    NUM,    // Numeric values (e.g., 10, 50, etc.)
    PARAM,  // "$" followed by a name (e.g., $x, $y)

    // Punctuation & Symbols
    COMMA,   // ","
    LBRACE,  // "{"
    RBRACE,  // "}"
    LPAREN,  // "("
    RPAREN,  // ")"

    // Keywords (TurtleScript , PostScript equivalent)
    PROC,     // "learn" , (Defines a procedure)
    IF,       // "if" , "if"
    ELSE,     // "else" , "else"
    REPEAT,   // "repeat" , "repeat"
    FORWARD,  // "forward" , "Forward"
    LEFT,     // "turnleft" , "Left"
    RIGHT,    // "turnright" , "Right"

    // Special Tokens
    EOI,      // End of Input (EOF)
    INVALID;  // Invalid Token (Unrecognized input)
}
