package turtlecompiler.lexer;

import java.io.InputStream;

public final class Lexer {
    private int current;
    private InputStream source;
    public int lineCounter = 1;

    public Lexer(InputStream input) {
        this.current = ' ';
        this.source = input;
    }

    // returns current line when lexing
    public int getLineCounter() {
        return lineCounter;
    }

    // gets the next character from the input stream
    private int getChar() {
        int ch = ' ';
        try {
            ch = source.read();
        } 
        //something went wrong with the read so we need to abort
        catch (Exception e) {
            System.out.println("--- Lexer error ---");
            System.out.println(e);
            System.exit(1);
        }
        return ch;
    }

    // gets next token
    public Token next() {
        // skip the white space
        while (current == ' ' || current == '\n' || current == '\t' || current == '\r') {
            if (current == '\n') {
                lineCounter++; // increments line counter when there is a new line
            }
            current = getChar();
        }

        // identify numeric values and return NUM tokens
        if (Character.isDigit(current)) {
            StringBuilder number = new StringBuilder();
            while (Character.isDigit(current)) {
                number.append((char) current); // add the digits that follow to the string builder
                current = getChar(); // move on to next token after lexing
            }
            return new Token(Type.NUM, number.toString(), number.toString(), 0);
        }
        
        // identify letters and return correct token
        if (Character.isLetter(current)) {
            StringBuilder word = new StringBuilder();
            while (Character.isLetterOrDigit(current)) {
                word.append((char) current); // add the letters or digits that follow to the string builder
                current = getChar(); // move on to next token after lexing 
            }
            String lexerme = word.toString();

            switch (lexerme) {
                case "learn":
                    return Token.PROC_TOKEN;
                case "if": 
                    return Token.IF_TOKEN;
                case "else":
                    return Token.ELSE_TOKEN;
                case "forward":
                    return Token.FORWARD_TOKEN;
                case "turnleft":
                    return Token.LEFT_TOKEN;
                case "turnright": 
                    return Token.RIGHT_TOKEN;
                case "repeat":
                    return Token.REPEAT_TOKEN;
                default:
                    return new Token(Type.IDENT, lexerme, lexerme, 0); // if the value is not a keyword then return an IDENT token
            }
        }
        
        // identify symbols and operators and return correct token
        switch (current) {
            case '+': 
                current = getChar(); 
                return Token.PLUS_TOKEN;
            case '-': 
                current = getChar(); 
                return Token.MINUS_TOKEN;
            case '*': 
                current = getChar(); 
                return Token.TIMES_TOKEN;
            case '/': 
                current = getChar(); 
                return Token.DIVIDE_TOKEN;
            case ',': 
                current = getChar(); 
                return Token.COMMA_TOKEN;
            case '{': 
                current = getChar(); 
                return Token.LBRACE_TOKEN;
            case '}': 
                current = getChar(); 
                return Token.RBRACE_TOKEN;
            case '(': 
                current = getChar(); 
                return Token.LPAREN_TOKEN;
            case ')': 
                current = getChar(); 
                return Token.RPAREN_TOKEN;
            case '=':
                current = getChar(); // get next token
                if (current == '=') { // EQ token requires two equal signs
                    current = getChar();
                    return Token.EQ_TOKEN;
                }
                return Token.INVALID_TOKEN; // if there is only one equal sign, return INVALID token
            case '!' :
                current = getChar(); // get next token
                if (current == '=' ) { // NE token requires an equal sign after the exclamation
                    current = getChar();
                    return Token.NE_TOKEN;
                }
                return Token.INVALID_TOKEN; // if there is only one exclamation sign, return INVALID token
            case '<' :
                current = getChar(); // get next token
                if (current == '=' ) { // if token is an equal sign, return less than or equal to token
                    current = getChar();
                    return Token.LE_TOKEN;
                }
                return Token.LT_TOKEN; // else return less than token
            case '>' :
                current = getChar(); // get next token
                if (current == '=' ) { // if next token is an equal sign, return greater than or equal to token
                    current = getChar();
                    return Token.GE_TOKEN;         
                }
                return Token.GT_TOKEN; // else return greater than token
        }

        // identifies PARAM tokens which start with the dollar sign
        if (current == '$') {
            StringBuilder param = new StringBuilder();
            param.append((char)current);                    
            current = getChar();
            while (Character.isLetterOrDigit(current)) { // add the following letters or digits to the string builder
                param.append((char)current);
                current = getChar();
            }
            return new Token(Type.PARAM, param.toString(), param.toString(), 0);
        }
        
        // identify the end of the turtle program and return EOI token
        if ( current == -1 ) {
            return Token.EOI_TOKEN;
        }

        // returns INVALID token for any other character or characters
        else {
            return Token.INVALID_TOKEN;
        }
    }
}
