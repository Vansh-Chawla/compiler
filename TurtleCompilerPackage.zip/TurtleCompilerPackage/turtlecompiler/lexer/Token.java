package turtlecompiler.lexer;
import java.io.*;

public class Token {
    //pre-defined objects for the real terminal objects (so excluding Num, Ident, Param)
    public static final Token COMMA_TOKEN = new Token(Type.COMMA, ",", ",", 0);
    public static final Token PROC_TOKEN = new Token(Type.PROC, "learn", "", 0);
    public static final Token EOI_TOKEN = new Token(Type.EOI, null, null, 0);
    public static final Token INVALID_TOKEN = new Token(Type.INVALID, null, null, 0);
    public static final Token ELSE_TOKEN = new Token(Type.ELSE, "else", "else", 0);
    public static final Token IF_TOKEN = new Token(Type.IF, "if", "if", 0);
    public static final Token REPEAT_TOKEN = new Token(Type.REPEAT, "repeat", "repeat", 0);
    public static final Token FORWARD_TOKEN = new Token(Type.FORWARD, "forward", "Forward", 0);
    public static final Token LEFT_TOKEN = new Token(Type.LEFT, "turnleft", "Left", 0);
    public static final Token RIGHT_TOKEN = new Token(Type.RIGHT, "turnright", "Right", 0);
    public static final Token LBRACE_TOKEN = new Token(Type.LBRACE, "{", "{", 0);
    public static final Token RBRACE_TOKEN = new Token(Type.RBRACE, "}", "}", 0);
    public static final Token LPAREN_TOKEN = new Token(Type.LPAREN, "(", "(", 0);
    public static final Token RPAREN_TOKEN = new Token(Type.RPAREN, ")", ")", 0);
    public static final Token PLUS_TOKEN = new Token(Type.PLUS, "+", "add", 3);
    public static final Token MINUS_TOKEN = new Token(Type.MINUS, "-", "sub", 3);
    public static final Token TIMES_TOKEN = new Token(Type.TIMES, "*", "mul", 4);
    public static final Token DIVIDE_TOKEN = new Token(Type.DIVIDE, "/", "div", 4);
    public static final Token EQ_TOKEN = new Token(Type.EQ, "==", "eq", 1);
    public static final Token NE_TOKEN = new Token(Type.NE, "!=", "ne", 1);
    public static final Token GE_TOKEN = new Token(Type.GE, ">=", "ge", 2);
    public static final Token GT_TOKEN = new Token(Type.GT, ">", "gt", 2);
    public static final Token LE_TOKEN = new Token(Type.LE, "<=", "le", 2);
    public static final Token LT_TOKEN = new Token(Type.LT, "<", "lt", 2);

    private final Type type;
    private final String turtleValue;
    private final String psValue;
    private final int precedence;

    public Token(Type type, String turtleValue, String psValue, int precedence) {
        this.type = type;
        this.turtleValue = turtleValue;
        this.psValue = psValue;
        this.precedence = precedence;
    }

    public Type getType() {
        return this.type;
    }

    public String getTurtleValue() {
        return turtleValue;
    }

    public String getPSValue() {
        return psValue;
    }

    public int getPrecedence() {
        return precedence;
    }
}
